#!/bin/sh

autoreconf --install --symlink --force
